using UnityEngine;
using System; 

[RequireComponent(typeof(Collider)), RequireComponent(typeof(Renderer))]
public class FingerCollisionDetector : MonoBehaviour
{
    public FingerCollisionManager.FingerType fingerType;
    public int boneIndex;
    public Color collisionColor = Color.blue;
    public string targetTag = "Player";
    
    private new Renderer renderer;
    private Color originalColor;
    private bool isColliding = false;

    void Start()
    {
        renderer = GetComponent<Renderer>();
        if (renderer != null)
        {originalColor = renderer.material.color;}
        if (FingerCollisionManager.Instance == null)
        {new GameObject("FingerCollisionManager").AddComponent<FingerCollisionManager>();}
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(targetTag))
        {
            isColliding = true;
            if (renderer != null)
            {renderer.material.color = collisionColor;}
            FingerCollisionManager.Instance?.UpdateBoneCollision(fingerType, boneIndex, true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag(targetTag))
        {
            isColliding = false;
            if (renderer != null){renderer.material.color = originalColor;}
            FingerCollisionManager.Instance?.UpdateBoneCollision(fingerType, boneIndex, false);
        }
    }
    
    public bool IsColliding(){return isColliding;}
}