using UnityEngine;
using System.Collections.Generic;

public class FingerCollisionManager : MonoBehaviour
{
    public enum FingerType { Thumb=0, Index=1, Middle=2, Ring=3, Pinky=4 }
    public static FingerCollisionManager Instance;
    private Dictionary<FingerType, bool[]> fingerCollisions = new Dictionary<FingerType, bool[]>();
    
    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            InitializeCollisionData();
        }
        else{Destroy(gameObject);}
    }
    







    void InitializeCollisionData()
    {
        foreach (FingerType finger in System.Enum.GetValues(typeof(FingerType)))
        {fingerCollisions[finger] = new bool[3];}
    }
    
    public void UpdateBoneCollision(FingerType finger, int boneIndex, bool isColliding)
    {
        if (boneIndex < 0 || boneIndex > 2) return;
        fingerCollisions[finger][boneIndex] = isColliding;
        CalculateAndSendAngle(finger);
    }
    





    private void CalculateAndSendAngle(FingerType finger)
    {
        int collisionCount = 0;
        foreach (bool collided in fingerCollisions[finger])
        {if (collided) collisionCount++;}
        
        int angle = 0;
        if (collisionCount == 1) angle = 90;
        else if (collisionCount == 2) angle = 135;
        else if (collisionCount >= 3) angle = 180;
        int fingerIndex = (int)finger;
        if (NetworkManager.Instance != null){NetworkManager.Instance.SendCommand(fingerIndex, angle);}
        else{Debug.LogWarning("NetworkManager not available to send command");}
    }
}