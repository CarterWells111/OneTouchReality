using UnityEngine;
using System;
using System.Net.Sockets;
using System.Text;

public class MiddleGenerator : MonoBehaviour
{
    [Header("Joint Settings")]
    public Transform startJoint;
    public Transform endJoint;

    [Header("Bone Settings")]
    public float radius = 0.001f;
    public FingerCollisionManager.FingerType fingerType;
    public Color collisionColor = Color.green;
    public int boneIndex;

    [Header("Collision Detection")]
    public string targetTag = "Player";

    private GameObject bone;
    private FingerCollisionDetector detector;

    void Start()
    {
        EnsureNetworkManager();
        CreateBone();
        if (FindObjectOfType<FingerCollisionManager>() == null)
        {new GameObject("FingerCollisionManager").AddComponent<FingerCollisionManager>();}
    }

    void EnsureNetworkManager()
    {
        if (NetworkManager.Instance == null)
        {
            NetworkManager existing = FindObjectOfType<NetworkManager>();
            if (existing == null)
            {
                GameObject networkManagerObj = new GameObject("NetworkManager");
                networkManagerObj.AddComponent<NetworkManager>();
            }
            else{NetworkManager.Instance = existing;}
        }
    }

    void CreateBone()
    {
        if (startJoint == null || endJoint == null)
        {
            Debug.LogError("关节未分配");
            return;
        }

        bone = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        bone.name = $"{fingerType}_Bone";
        bone.tag = "Bone";

        CapsuleCollider collider = bone.GetComponent<CapsuleCollider>();
        collider.isTrigger = true;
        collider.radius = radius * 1.5f;
        collider.direction = 1; // Y

        detector = bone.AddComponent<FingerCollisionDetector>();
        detector.fingerType = fingerType;
        detector.collisionColor = collisionColor;
        detector.targetTag = targetTag;
        detector.boneIndex = boneIndex;

        Renderer renderer = bone.GetComponent<Renderer>();
        renderer.material = new Material(Shader.Find("Standard"));
        renderer.material.color = Color.white;

    }
    void LateUpdate()
    {
        if (startJoint == null || endJoint == null || bone == null) return;

        Vector3 midPoint = (startJoint.position + endJoint.position) / 2f;
        Vector3 direction = endJoint.position - startJoint.position;
        float distance = direction.magnitude;

        bone.transform.position = midPoint;
        bone.transform.up = direction.normalized;
        bone.transform.localScale = new Vector3(radius * 2, distance / 2, radius * 2);

        CapsuleCollider collider = bone.GetComponent<CapsuleCollider>();
        collider.height = distance;
    }
}