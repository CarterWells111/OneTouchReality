using UnityEngine;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class UDPReceiver : MonoBehaviour
{
    public int port = 5065;
    private UdpClient udpClient;
    private Thread receiveThread;
    private bool isRunning = true;
    private string receivedData = "";
    private bool newDataAvailable = false;

    [System.Serializable]
    public class HandData
    {
        public List<Landmark> landmarks;
        public string gesture;
        public float fps;
        public double timestamp;
    }

    [System.Serializable]
    public class Landmark
    {
        public float x;
        public float y;
        public float z;
        public int id;
    }

    public HandData currentHandData { get; private set; }

    void Start()
    {
        currentHandData = new HandData
        {
            landmarks = new List<Landmark>(),
            gesture = "NONE",
            fps = 0,
            timestamp = 0
        };
        udpClient = new UdpClient(port);
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();

        Debug.Log($"UDP Receiver started on port {port}");
    }









    private void ReceiveData()
    {
        IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, port);
        while (isRunning)
        {
            try
            {
                byte[] data = udpClient.Receive(ref anyIP);
                receivedData = Encoding.UTF8.GetString(data);
                newDataAvailable = true;
            }
            catch (Exception e)
            {
                Debug.LogError(e.ToString());
            }
        }
    }







    

    void Update()
    {
        if (newDataAvailable)
        {
            ParseReceivedData();
            newDataAvailable = false;
        }
    }










    private void ParseReceivedData()
    {
        try{currentHandData = JsonUtility.FromJson<HandData>(receivedData);}
        catch (Exception e){Debug.LogError("Parse Error: " + e.Message);}
    }

    void OnDestroy()
    {
        isRunning = false;
        if (receiveThread != null && receiveThread.IsAlive)
            receiveThread.Abort();
        if (udpClient != null)
            udpClient.Close();
    }
}