using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class HandController : MonoBehaviour
{
    public UDPReceiver udpReceiver;
    public bool mirrorHand = true;

    // root
    public Transform handRoot;
    
    // joints
    public Transform wrist;
    public Finger thumb;
    public Finger index;
    public Finger middle;
    public Finger ring;
    public Finger pinky;

    public float positionSmooth = 15f;
    public float globalScale = 1.0f;
    public float scale = 0.1f; // 用于缩放距离计算

    [Header("距离显示")]
    public bool showDistance = true; 
    public Text DT;
    public Vector2 textPosition = new Vector2(20, 20);
    public Color textColor = Color.green;
    public int fontSize = 24;

    [System.Serializable]
    public class Finger
    {
        public Transform mcp;
        public Transform pip;
        public Transform dip;
        public Transform tip;
    }
    private List<Transform> allJoints = new List<Transform>();
    private float wristToThumbDistance = 0f;
    
    void Start()
    {
        CollectJoints();
        InitializeDistanceDisplay();
    }
    





    void CollectJoints()
    {
        if (wrist) allJoints.Add(wrist);
        AddFingerJoints(thumb);
        AddFingerJoints(index);
        AddFingerJoints(middle);
        AddFingerJoints(ring);
        AddFingerJoints(pinky);
    }
    
    void AddFingerJoints(Finger finger)
    {
        if (finger == null) return;
        if (finger.mcp) allJoints.Add(finger.mcp);
        if (finger.pip) allJoints.Add(finger.pip);
        if (finger.dip) allJoints.Add(finger.dip);
        if (finger.tip) allJoints.Add(finger.tip);
    }







    void Update()
    {
        if (udpReceiver == null || udpReceiver.currentHandData == null ||
            udpReceiver.currentHandData.landmarks == null ||
            udpReceiver.currentHandData.landmarks.Count < 21)
            return;

        UpdateHandRootPosition();
        UpdateJointPositions();
        CalculateWristToThumbDistance();
        UpdateDistanceDisplay();
        //globalScale = (scale / wristToThumbDistance)*0.1f;
    }
    


















    void UpdateHandRootPosition()
    {
        if (handRoot == null) return;
        var wristLandmark = udpReceiver.currentHandData.landmarks[0];
        Vector3 wristPosition = new Vector3(
            mirrorHand ? -wristLandmark.x : wristLandmark.x,
            wristLandmark.y,
            wristLandmark.z
        ) * globalScale;
        handRoot.localPosition = Vector3.Lerp(
            handRoot.localPosition,
            wristPosition,
            Time.deltaTime * positionSmooth
        );
    }

    void UpdateJointPositions()
    {
        UpdateJointPosition(wrist, 0);
        UpdateFingerPosition(thumb, 1, 2, 3, 4);
        UpdateFingerPosition(index, 5, 6, 7, 8);
        UpdateFingerPosition(middle, 9, 10, 11, 12);
        UpdateFingerPosition(ring, 13, 14, 15, 16);
        UpdateFingerPosition(pinky, 17, 18, 19, 20);
    }
    
    void UpdateFingerPosition(Finger finger, int mcpIdx, int pipIdx, int dipIdx, int tipIdx)
    {
        if (finger == null) return;
        
        UpdateJointPosition(finger.mcp, mcpIdx);
        UpdateJointPosition(finger.pip, pipIdx);
        UpdateJointPosition(finger.dip, dipIdx);
        UpdateJointPosition(finger.tip, tipIdx);
    }

    void UpdateJointPosition(Transform joint, int landmarkIndex)
    {
        if (joint == null || landmarkIndex >= udpReceiver.currentHandData.landmarks.Count)
            return;

        var landmark = udpReceiver.currentHandData.landmarks[landmarkIndex];
        
        var wristLandmark = udpReceiver.currentHandData.landmarks[0];
        Vector3 relativePosition = new Vector3(
            landmark.x - wristLandmark.x,
            landmark.y - wristLandmark.y,
            landmark.z - wristLandmark.z
        );
        
        if (mirrorHand) relativePosition.x = -relativePosition.x;
        relativePosition *= globalScale;

        joint.localPosition = Vector3.Lerp(
            joint.localPosition,
            relativePosition,
            Time.deltaTime * positionSmooth
        );
    }
    
    void CalculateWristToThumbDistance()
    {
        if (wrist != null && thumb != null && thumb.mcp != null)
        {
            wristToThumbDistance = Vector3.Distance(
                wrist.position, 
                thumb.mcp.position
            );
        }
    }
    
    void InitializeDistanceDisplay()
    {
    Font font = Resources.GetBuiltinResource<Font>("Arial.ttf");
    
    if (font == null)
    {
        Debug.LogWarning("Arial font not found, using default");
        return;
    }
        if (DT == null && showDistance)
        {
            GameObject textGO = new GameObject("DT");
            textGO.transform.SetParent(transform);
            
            DT = textGO.AddComponent<Text>();
            DT.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            DT.rectTransform.sizeDelta = new Vector2(400, 100);
            DT.rectTransform.anchorMin = new Vector2(0, 1);
            DT.rectTransform.anchorMax = new Vector2(0, 1);
            DT.rectTransform.pivot = new Vector2(0, 1);
            DT.rectTransform.anchoredPosition = textPosition;
            
            DT.color = textColor;
            DT.fontSize = fontSize;
            DT.horizontalOverflow = HorizontalWrapMode.Overflow;
            DT.verticalOverflow = VerticalWrapMode.Overflow;
        }
    }
    
    void UpdateDistanceDisplay()//label distance
    {
        if (showDistance && DT != null)
        {
            DT.text = $"wrist to thumb: {wristToThumbDistance.ToString("F4")}";
        }
    }
    
    void OnGUI()
    {
        if (showDistance && (DT == null || !DT.gameObject.activeInHierarchy))
        {
            GUIStyle style = new GUIStyle();
            style.fontSize = fontSize;
            style.normal.textColor = textColor;
            
            GUI.Label(
                new Rect(textPosition.x, textPosition.y, 400, 100), 
                $"wrist to thumb: {wristToThumbDistance.ToString("F4")}",
                style
            );
        }
    }
    
    void OnDrawGizmos()
    {
        if (!Application.isPlaying) return;
        
        DrawFinger(wrist.position, thumb);
        DrawFinger(wrist.position, index);
        DrawFinger(wrist.position, middle);
        DrawFinger(wrist.position, ring);
        DrawFinger(wrist.position, pinky);
        
        if (wrist != null && thumb != null && thumb.mcp != null)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawLine(wrist.position, thumb.mcp.position);
            
            Vector3 midPoint = (wrist.position + thumb.mcp.position) / 2;
            UnityEditor.Handles.Label(midPoint, $"{wristToThumbDistance.ToString("F3")}", new GUIStyle()
            {
                normal = new GUIStyleState() { textColor = Color.magenta },
                fontSize = 14
            });
        }
    }
    
    void DrawFinger(Vector3 wristPos, Finger finger)
    {
        if (finger == null) return;
        
        Gizmos.color = Color.blue;
        if (finger.mcp) 
        {
            Gizmos.DrawLine(wristPos, finger.mcp.position);
            if (finger.pip) Gizmos.DrawLine(finger.mcp.position, finger.pip.position);
            if (finger.dip) Gizmos.DrawLine(finger.pip.position, finger.dip.position);
            if (finger.tip) Gizmos.DrawLine(finger.dip.position, finger.tip.position);
        }
    }
}