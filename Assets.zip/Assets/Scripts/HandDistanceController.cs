using UnityEngine;

public class HandDistanceController : MonoBehaviour
{
    [Header("Joint References")]
    public Transform wristJ;     
    public Transform thumbBaseJ;
    
    [Header("Distance Control Parameters")]
    public float smoothSpeed = 50f;
    public float minD = 0.002f;
    public float maxD = 0.01f;
    public float minZ = 1.0f;
    public float maxZ = 0.1f;
    
    [Header("Bais")]
    public Vector3 Bais = new Vector3(0, 0, 0);

    private Vector3 intial;
    private float Z;
    
    void Start()
    {
        intial = transform.position;
        if (!wristJ || !thumbBaseJ)
        {
            Debug.LogError("分配");
            enabled = false;
        }
    }

    void LateUpdate()
    {
        if (!wristJ || !thumbBaseJ) return;
        float currentJD = Vector3.Distance(wristJ.position, thumbBaseJ.position);

        if (currentJD < 0.0001f) return;
        Z = -(0.00225f / currentJD - 0.1f);
        ApplyPosition();
    }
    








    void ApplyPosition()
    {
        Vector3 targetPosition = new Vector3(transform.position.x + Bais.x,transform.position.y + Bais.y,Z + Bais.z);
        //ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZz
        transform.position = Vector3.Lerp(transform.position, targetPosition, Time.deltaTime * smoothSpeed);
    }
    
    void OnDrawGizmos()
    {
        if (!Application.isPlaying || !wristJ || !thumbBaseJ) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(wristJ.position, thumbBaseJ.position);
        Vector3 midPoint = (wristJ.position + thumbBaseJ.position) / 2f;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(new Vector3(midPoint.x, midPoint.y, Z), 0.01f);
    }
}