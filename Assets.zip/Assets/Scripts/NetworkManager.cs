using UnityEngine;
using System;      
using System.Net.Sockets;
using System.Text;   
public class NetworkManager : MonoBehaviour
{
    public static NetworkManager Instance;
    
    [Header("Python Server")]
    public string IP = "127.0.0.1";
    public int port = 8000;
    
    private TcpClient client;
    private NetworkStream stream;
    
    void Awake()
    {
        if (Instance == null) {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            ConnectToServer();
        } 
        else {Destroy(gameObject);}
    }
    
    void ConnectToServer()
    {
        try {
            client = new TcpClient(IP, port);
            stream = client.GetStream();
            Debug.Log("Connected to Python server");
        }
        catch (Exception e) {
            Debug.LogError("Connection failed: " + e.Message);
            Invoke("ConnectToServer", 5f);
        }
    }
    
    public void SendCommand(int finger, int angle)
    {
        if (stream == null || !client.Connected) {
            Debug.LogWarning("Python server not connected");
            return;
        }
        
        try {
            string command = $"{finger},{angle}\n";
            byte[] data = Encoding.ASCII.GetBytes(command);
            stream.Write(data, 0, data.Length);
            Debug.Log($"Sent: Finger={finger}, Angle={angle}");
        }
        catch (Exception e) {Debug.LogError("Send failed: " + e.Message);}
    }
    
    void OnDestroy()
    {
        if (stream != null) stream.Close();
        if (client != null) client.Close();
    }
}

